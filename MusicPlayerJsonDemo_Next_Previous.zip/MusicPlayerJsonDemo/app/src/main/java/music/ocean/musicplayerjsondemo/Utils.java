package music.ocean.musicplayerjsondemo;

import java.util.ArrayList;

/**
 * Created by savan123 on 6/9/2018.
 */

public class Utils {
    public static ArrayList<String> musicurl;
}
