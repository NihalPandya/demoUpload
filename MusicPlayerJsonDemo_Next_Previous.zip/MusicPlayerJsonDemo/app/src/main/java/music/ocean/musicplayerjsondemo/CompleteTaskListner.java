package music.ocean.musicplayerjsondemo;


public interface CompleteTaskListner
{
    public void completeTask(String result, int response_code);
}