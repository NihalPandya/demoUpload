package music.ocean.musicplayerjsondemo;

import java.util.ArrayList;

public class MusicBean
{
    public String title;
    public String mp3url;

    public MusicBean(String title, String mp3url) {
        this.title = title;
        this.mp3url = mp3url;
    }

}
