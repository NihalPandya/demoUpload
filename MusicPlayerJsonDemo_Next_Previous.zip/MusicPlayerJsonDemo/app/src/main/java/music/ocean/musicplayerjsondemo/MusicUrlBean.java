package music.ocean.musicplayerjsondemo;

import android.view.SurfaceHolder;

import java.util.ArrayList;

public class MusicUrlBean{
    public String url;

    public MusicUrlBean(String url)
    {
        this.url = url;
    }
}
