package music.ocean.musicplayerjsondemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MusicAdapter extends ArrayAdapter<MusicBean> {
    ArrayList<MusicBean> drawerlist;
    Context context;

    public MusicAdapter(Context context, ArrayList<MusicBean> drawerlist) {
        super(context, R.layout.raw_music_item, drawerlist);
        this.drawerlist = drawerlist;
        this.context = context;
    }

    class Holder {
        TextView txtsongTitle;
    }
    public int getCount() {
        return super.getCount();
    }

    public View getView(final int position, View convertView, ViewGroup parent)
    {
        MusicBean data = drawerlist.get(position);
        final Holder viewHolder;
        if (convertView == null)
        {
            viewHolder = new Holder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.raw_music_item, parent, false);
            viewHolder.txtsongTitle = (TextView) convertView.findViewById(R.id.textsongtitle);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (Holder) convertView.getTag();
        }

        viewHolder.txtsongTitle.setText(data.title);
        return convertView;
    }

}
