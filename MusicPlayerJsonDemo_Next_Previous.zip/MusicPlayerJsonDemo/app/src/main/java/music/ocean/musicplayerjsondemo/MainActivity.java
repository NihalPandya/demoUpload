package music.ocean.musicplayerjsondemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CompleteTaskListner {

   private ListView musiclistView;
   private ArrayList<MusicBean> Musiclist;
   private MusicAdapter musicAdapter;
//   private ArrayList<String> musicurl;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        musiclistView = (ListView) findViewById(R.id.listview);
        Musiclist = new ArrayList<>();
        Utils.musicurl = new ArrayList<>();

        musiclistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
//                Intent mymusic = new Intent(getApplicationContext(),Player.class);
//                mymusic.putExtra("pos",position);
//
//                mymusic.putExtra("songlist",ArrayList)
//                //Toast.makeText(getApplicationContext(),"view===>",musicurl.get(position),Toast.LENGTH_LONG).show();
//                startActivity(mymusic);

                Intent myintent = new Intent(getApplicationContext(),Player.class);
                myintent.putExtra("pos",position);
//                myintent.putExtra("songlist",Utils.musicurl.get(position));
//                myintent.putExtra("listValue",Utils.musicurl);
                startActivity(myintent);
            }
        });

        CallApi();
    }

    private void CallApi()
    {
        List<Pair<String, String>> params = new ArrayList<>();
        params.add(new Pair<String, String>("action","view_music"));
        new AsyncHttpsRequest("Please Wiat..",MainActivity.this, params,this, 1,false).execute("http://mirabaibhajan.eontechno.com/mirabaiapi.php");
    }

    @Override
    public void completeTask(String result, int response_code)
    {
        switch (response_code)
        {
            case 1:
                //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                try
                {
                    JSONObject jobj =  new JSONObject(result);
                    String status = jobj.getString("status");
                    if (status.equals(status))
                    {
                        JSONArray jArray = jobj.getJSONArray("data");
                        for (int i=0; i<jArray.length();i++)
                        {
                            JSONObject job = jArray.getJSONObject(i);
                            String name = job.getString("name");
                            String mp3 = job.getString("mp3");
                            Musiclist.add(new MusicBean(name,mp3));
                            Utils.musicurl.add(mp3);

                        }
                        musicAdapter = new MusicAdapter(getApplicationContext(),Musiclist);
                        musiclistView.setAdapter(musicAdapter);
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
                break;
        }

    }
}
