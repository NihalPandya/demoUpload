package music.ocean.musicplayerjsondemo;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;

import org.json.JSONArray;

import java.util.ArrayList;

public class Player extends AppCompatActivity implements View.OnClickListener {
    static MediaPlayer mp;
    int position;
    int resId;
    //String message;
    //Thread updateSeekBar;
    private int currentSongIndex = 0;
    //SeekBar seekBar;
    Handler mHandler = new Handler();
    ;
    ImageView imgplay, imgnext, imgpre, imgback;
    //ArrayList<String> songlist;
    private int nextvar = 1;
    private int Url;
    private String music_link;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_player);

        imgplay = (ImageView) findViewById(R.id.imgplay);
        imgnext = (ImageView) findViewById(R.id.imgnext);
        imgpre = (ImageView) findViewById(R.id.imgprevious);
        imgback = (ImageView) findViewById(R.id.imageback);
        //seekBar = (SeekBar) findViewById(R.id.seekbar);

        imgplay.setOnClickListener(this);
        imgpre.setOnClickListener(this);
        imgnext.setOnClickListener(this);

        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        /*updateSeekBar = new Thread()
        {
            public void run()
            {
                int totalDuration =   mp.getDuration();
                int currentPosition = 0;
                seekBar.setMax(totalDuration);
                while (currentPosition < totalDuration)
                {
                    try
                    {
                        sleep( 500);
                        currentPosition = mp.getCurrentPosition();
                        seekBar.setProgress(currentPosition);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                super.run();
            }
        };*/

        Bundle bundle = getIntent().getExtras();
        //message = bundle.getString("songlist");
        position = bundle.getInt("pos", 0);
        music_link=Utils.musicurl.get(position);
        //Url=songlist.size();

        Log.i("TotalSong==>", String.valueOf(Utils.musicurl.size()));

        //Url="http://mirabaibhajan.eontechno.com/songs/152757914405 - Tujhe Bhula Diya (www.pagalworld.com).mp3";
        //resId = getResources().getIdentifier(message,"raw",getPackageName());

        mp = MediaPlayer.create(Player.this, Uri.parse(String.valueOf(music_link)));
        mp.start();
        //seekBar.setMax(mp.getDuration());

        //songlist = (ArrayList<String>) getIntent().getSerializableExtra("listValue");
        /*seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                mHandler.removeCallbacks(mUpdateTimeTask);
            }

            public void onStopTrackingTouch(SeekBar seekBar)
            {
                mHandler.removeCallbacks(mUpdateTimeTask);
                updateProgressBar();
                mp.seekTo(seekBar.getProgress());
            }
        });*/
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.imgplay:
                if (mp.isPlaying()) {
                    if (mp != null) {
                        mp.pause();
                        imgplay.setImageResource(R.drawable.pause);
                    }
                } else {
                    if (mp != null) {
                        mp.start();
                        imgplay.setImageResource(R.drawable.play);
                    }
                }
                break;

            case R.id.imgnext:

//                if (Utils.musicurl.size() <= nextvar) {
//                    nextvar = 0;
//                } else {
//                    mp.release();
//                    String song = Utils.musicurl.get(currentSongIndex + nextvar);
//                    //Url="http://mirabaibhajan.eontechno.com/songs/152757914405 - Tujhe Bhula Diya (www.pagalworld.com).mp3";
//                    //resId = getResources().getIdentifier(song,"Url",getPackageName());
//                    //mp = MediaPlayer.create(getApplicationContext(),Uri.parse(song));
//                    //mp.start();
//                    //seekBar.setMax(mp.getDuration());
//
//                    Log.i("Viewsong==>", Utils.musicurl.get(position).toString());
//                    nextvar++;
//                }
                position++;
                if(position>=Utils.musicurl.size())
                {
                    position=0;
                }
                if(position>-1 && position<Utils.musicurl.size())
                {
                    stopPlaying();
                    playMusic(Utils.musicurl.get(position));
                }


                break;

            case R.id.imgprevious:
//                try {
//                    if (Utils.musicurl.size() <= nextvar) {
//                        nextvar = 0;
//                    } else {
//                        mp.release();
//                        String song = Utils.musicurl.get(currentSongIndex + nextvar);
//                        //Url="http://mirabaibhajan.eontechno.com/songs/152757914405 - Tujhe Bhula Diya (www.pagalworld.com).mp3";
//                        //resId = getResources().getIdentifier(song, "Url", getPackageName());
//                        mp = MediaPlayer.create(getApplicationContext(), Uri.parse(song));
//                        mp.start();
//                        //seekBar.setMax(mp.getDuration());
//                        nextvar--;
//                    }
//                    break;
//                } catch (NullPointerException e) {
//                    e.printStackTrace();
//                }

                position--;
                if(position<0)
                {
                    position=Utils.musicurl.size()-1;
                }
                if(position>-1 && position<Utils.musicurl.size())
                {
                    stopPlaying();
                    playMusic(Utils.musicurl.get(position));
                }
        }
    }

    public void playMusic(String local_music)
    {
        if (mp == null) {
            mp = MediaPlayer.create(Player.this, Uri.parse(local_music));
            mp.start();
        }
        else{
            if (mp.isPlaying()) {
                mp.stop();
                mp.release();
                mp = MediaPlayer.create(Player.this, Uri.parse(local_music));
                mp.start();
            }
        }

    }
    public void stopPlaying()
    {
        if (mp != null) {
            if (mp.isPlaying()) {
                mp.stop();
                mp.release();
                mp = null;
            }
        }
    }
    /*private void updateProgressBar()
    {
            mHandler.postDelayed(mUpdateTimeTask, 100);
    }
    private Runnable mUpdateTimeTask = new Runnable()
    {
        public void run()
        {
            mHandler.postDelayed(this, 100); }
        };
        public void onDestroy() {
            super.onDestroy();
            mp.release();
        }*/
}

